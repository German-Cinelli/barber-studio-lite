<?php

namespace Facades\App\Livewire\Actions\Dashboard\Schedule;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Livewire\Actions\Dashboard\Schedule\GetScheduleForDayAction
 */
class GetScheduleForDayAction extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Livewire\Actions\Dashboard\Schedule\GetScheduleForDayAction';
    }
}
