<div class="row">

    <div class="col-sm-12 col-md-6 col-lg-8">
        <div class="card mb-4">
            <div class="card-header">
                <strong># Datos</strong>
            </div>

            <div class="card-body">

                <!-- name -->
                <div class="form-floating mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'form.name','label' => 'Nombre','type' => 'text','wire:model' => 'form.name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.name','label' => 'Nombre','type' => 'text','wire:model' => 'form.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <!-- phone -->
                <div class="form-floating mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'form.phone','label' => 'Teléfono','type' => 'number','wire:model' => 'form.phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.phone','label' => 'Teléfono','type' => 'number','wire:model' => 'form.phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <!-- employee_id -->
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-select','data' => ['name' => 'form.employee_id','label' => 'Empleado','wire:model.blur' => 'form.employee_id','wire:change' => 'changeEmployee','collection' => $employees]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.employee_id','label' => 'Empleado','wire:model.blur' => 'form.employee_id','wire:change' => 'changeEmployee','collection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employees)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <!-- date -->
                <div class="form-floating mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'form.date','id' => 'dateAppointment','label' => 'Fecha','type' => 'date','wire:model' => 'form.date','wire:change' => 'changeDate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.date','id' => 'dateAppointment','label' => 'Fecha','type' => 'date','wire:model' => 'form.date','wire:change' => 'changeDate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <!-- time -->
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-select-schedule','data' => ['name' => 'form.time','label' => 'Horario','wire:model.blur' => 'form.time','collection' => $availableSchedules]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select-schedule'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.time','label' => 'Horario','wire:model.blur' => 'form.time','collection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($availableSchedules)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <button wire:click="save" type="submit" class="btn btn-primary float-end">
                    Ingresar
                </button>

            </div>
        </div>

    </div>

    <div class="col-sm-12 col-md-6 col-lg-4">
        <div class="card mb-4">
            <div class="card-header">
                <strong># Servicios</strong>
            </div>

            <div class="card-body">

                <div class="table-responsive" style="max-height: 408px; overflow-y: auto;">
                    <table class="table align-middle caption-top">
                        <caption>
                            Total: <?php echo e($durationTime); ?> min
                        </caption>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div wire:key="<?php echo e($service->id); ?>">
                                    <tr>
                                        <th scope="row">
                                            <div class="form-check">
                                                <input wire:model="form.services" wire:click="toggleService" class="form-check-input" type="checkbox" value="<?php echo e($service->id); ?>"
                                                    id="flexCheckServiceId<?php echo e($service->id); ?>">
                                            </div>
                                        </th>
                                        <td>
                                            <label class="form-check-label" for="flexCheckServiceId<?php echo e($service->id); ?>"
                                                style="user-select: none; cursor: pointer">
                                                <div class="avatar" title="<?php echo e($service->item->name); ?>">
                                                    <img class="avatar-img"
                                                        src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>"
                                                        alt="<?php echo e($service->item->name); ?>">

                                                </div>
                                                <?php echo e($service->item->name); ?>

                                                <small>(<?php echo e($service->duration_time); ?> min)</small>
                                            </label>
                                        </td>
                                    </tr>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">
                                        Sin resultados
                                    </td>
                                </tr>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>

                </div>

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        Seleccione al menos un servicio
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->

            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            var currentDate = new Date().toISOString().split('T')[0];
            document.getElementById('dateAppointment').setAttribute('min', currentDate);
        </script>
    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointments/create-appointment.blade.php ENDPATH**/ ?>