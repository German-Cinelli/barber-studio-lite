<?php

namespace Facades\App\Livewire\Actions\Dashboard\Image;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Livewire\Actions\Dashboard\Image\CreateAction
 */
class CreateAction extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Livewire\Actions\Dashboard\Image\CreateAction';
    }
}
