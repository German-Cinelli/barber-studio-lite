<div class="row">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 bottommargin">
            <div class="team">
                <div class="team-image">
                    <img src="<?php echo e(asset($this->small('storage/employees/', $employee->image))); ?>"
                        alt="<?php echo e($employee->name); ?>" width="128px">
                    <div class="bg-overlay">
                        <div
                            class="bg-overlay-content p-2 flex-column-reverse justify-content-between align-items-center">
                            <div class="d-flex mb-3" data-hover-animate="fadeInUp" data-hover-animate-out="fadeOutDown"
                                data-hover-speed="400" data-hover-parent=".team">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $employee->socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($social->pivot->href); ?>" target="_blank" class="social-icon si-rounded si-colored si-small si-<?php echo e(strtolower($social->name)); ?>" title="<?php echo e($social->name); ?>">
                                        <i class="icon-<?php echo e($social->icon); ?>"></i>
                                        <i class="icon-<?php echo e($social->icon); ?>"></i>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <a href="#" class="button button-large button-color m-0 w-100 text-center"
                                data-hover-animate="fadeInDown" data-hover-animate-out="fadeOutUp"
                                data-hover-speed="400" data-hover-parent=".team">Appointment</a>
                        </div>
                        <div class="bg-overlay-bg dark" data-hover-animate="fadeIn" data-hover-speed="400"
                            data-hover-parent=".team"></div>
                    </div>
                </div>
                <div class="team-desc">
                    <div class="team-title">
                        <h4><?php echo e($employee->name); ?></h4>
                        <span><?php echo e($employee->description); ?></span>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

</div><?php /**PATH /var/www/html/resources/views/livewire/frontend/employees/list-employees.blade.php ENDPATH**/ ?>