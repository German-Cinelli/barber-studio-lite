<?php

namespace Facades\App\Livewire\Actions\Dashboard\Employee;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Livewire\Actions\Dashboard\Employee\UpdateStatusAction
 */
class UpdateStatusAction extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Livewire\Actions\Dashboard\Employee\UpdateStatusAction';
    }
}
