<div>
    <a wire:click="delete" class="dropdown-item" href="javascript:void(0)">
        <i class="cil-trash text-danger"></i>
        Eliminar
    </a>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/categories/delete-category.blade.php ENDPATH**/ ?>