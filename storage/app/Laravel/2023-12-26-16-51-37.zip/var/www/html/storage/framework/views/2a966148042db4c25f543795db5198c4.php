<div>
    <form wire:submit="save">

        <?php echo $__env->make('livewire.dashboard.items.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button type="submit" class="btn btn-warning float-end">
            Actualizar
            <div wire:loading.delay class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden"></span>
            </div>
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/items/update-item.blade.php ENDPATH**/ ?>