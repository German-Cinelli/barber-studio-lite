<div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Slug <i class="cil-info text-info" title="URL en la cual se podrán visualizar todos los productos relacionados a una categoría."></i></th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($category->id); ?>">
                    <tr>
                        <th scope="row"><?php echo e($category->id); ?></th>
                        <td>
                            <?php echo $category->trashed() ? '<del>' . $category->name . '</del>' : $category->name; ?>

                        </td>
                        <td><code>/<?php echo e($category->slug); ?></code></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($category->trashed()): ?>
                                <button wire:click="restore(<?php echo e($category->id); ?>)" wire:confirm="¿Deseas restaurar *<?php echo e($category->name); ?>*?" class="btn btn-outline-success" type="button" title="Restaurar">
                                    <i class="cil-recycle"></i>
                                </button>
                            <?php else: ?>
                                <div class="btn-group" role="group" aria-label="Default button group">
                                    <button class="btn btn-outline-primary" type="button" title="Editar">
                                        <i class="cil-pencil"></i>
                                    </button>
                                    <button wire:click="delete(<?php echo e($category->id); ?>)" wire:confirm="¿Deseas eliminar *<?php echo e($category->name); ?>*?" class="btn btn-outline-primary" type="button" title="Eliminar">
                                        <i class="cil-trash"></i>
                                    </button>
                                </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">
                        Sin resultados.
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($categories->links()); ?>

    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/categories/category-list.blade.php ENDPATH**/ ?>