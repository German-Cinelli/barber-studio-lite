<div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.orders.List-orders-in-backdrop', []);

$__html = app('livewire')->mount($__name, $__params, '8ZDgd67', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.appointments.create-simple-appointment', []);

$__html = app('livewire')->mount($__name, $__params, 'VrTATi2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Tablero</span></li>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('button-in-tab'); ?>
        <button class="btn btn-info position-relative rounded-0 float-end" type="button" data-coreui-toggle="offcanvas" data-coreui-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">
            <svg class="icon">
                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-hamburger-menu')); ?>"></use>
            </svg>
            Tickets
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.orders.notify-icon', []);

$__html = app('livewire')->mount($__name, $__params, 'z55A5eA', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </button>
    <?php $__env->stopSection(); ?>

    <div class="row">

        <!--<div class="mb-3">
            <button class="btn btn-info position-relative rounded-0 float-end" type="button" data-coreui-toggle="offcanvas" data-coreui-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-hamburger-menu')); ?>"></use>
                </svg>
                Tickets
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.orders.notify-icon', []);

$__html = app('livewire')->mount($__name, $__params, '3EuTfJk', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </button>
        </div>-->

        <div class="col-sm-12 col-md-6 col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Lista de espera</strong>


                </div>

                <div class="card-body" style="min-height: 550px; max-height: 550px; overflow-y: auto;">

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.appointments.list-appointments-cards', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'AblpiX4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                </div>
            </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Empleados</strong>
                </div>

                <div class="container">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.board.employee-component', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'fGqQr3i', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

            </div>
        </div>
    </div>

    <?php $__env->startPush('css'); ?>
    <style>

        @keyframes titilar {
            0% {
                color: black;
                /* Color inicial */
            }

            50% {
                color: red;
                /* Color intermedio (rojo) */
            }

            100% {
                color: black;
                /* Color final (vuelve a negro) */
            }
        }

        .titulo-titilante {
            animation: titilar 1s infinite;
            /* La animación dura 1 segundo y se repite infinitamente */
        }

        .btn-add-service {
            visibility: hidden;
            opacity: 0; /* Inicialmente transparente */
            transition: opacity 0.3s ease;
        }

        .service-container:hover .btn-add-service {
            visibility: visible;
            cursor: pointer;
            opacity: 1;
        }
    </style>
    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/board-component.blade.php ENDPATH**/ ?>