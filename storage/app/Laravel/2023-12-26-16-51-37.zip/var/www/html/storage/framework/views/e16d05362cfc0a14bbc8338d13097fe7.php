<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Tickets</span></li>
    <?php $__env->stopSection(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Listado de tickets</strong>
        </div>

        <div class="card-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.search-component', []);

$__html = app('livewire')->mount($__name, $__params, 'Sy8j3Bx', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.orders.list-orders', []);

$__html = app('livewire')->mount($__name, $__params, 'wKA7kQn', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/order-component.blade.php ENDPATH**/ ?>