<div wire:ignore.self class="modal fade" id="modal-instagram-feed-faq">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">
                    Información
                </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div><!-- /.modal-header -->

            <form>
                <div class="card-body">
                    <div class="row">

                        <div id="accordion">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h4 class="card-title w-100">
                                        <a class="d-block w-100" data-toggle="collapse" href="#collapseOne"
                                            aria-expanded="true">
                                            ¿Cómo añadir publicaciones de Instagram a mi sitio?
                                        </a>
                                    </h4>
                                </div>
                                <div class="card-body">
                                    <p class="lead">
                                        Para hacerlo, dirígase a la publicación de Instagram que desea insertar al sitio
                                        y presione sobre el ícono <i class="fa fa-ellipsis-h"></i>
                                    </p>
                                    <p class="lead">Se desplegará un menú similar al siguiente:</p>
                                    <ul>
                                        <li>Reportar</li>
                                        <li>Ir a la publicación</li>
                                        <li>Compartir en...</li>
                                        <li>Copiar enlace</li>
                                        <li>Insertar</li>
                                        <li>Información sobre esta cuenta</li>
                                    </ul>
                                    <p class="lead">
                                        Luego de presionar sobre la opción <strong>Insertar</strong>, se despliega un
                                        botón para copiar el código de inserción.
                                        Tras copiarlo volvemos aquí y presionarmos sobre el botón <i
                                            class="fa fa-plus text-primary"></i> para guardarlo.
                                    </p>

                                    <div class="callout callout-info">
                                        <h5>Atención!</h5>
                                        <p>Se recomienda marcar la opción <strong>Incluir pie de foto</strong> para
                                            publicaciones con descripción no muy extensas.</p>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div><!-- /.row -->
                </div><!-- /.card-body -->

            </form>

            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i></button>
                <button wire:click="openModalCreate" type="button" class="btn btn-primary">
                    Volver
                    <i class="fa fa-chevron-right"></i>
                </button>
            </div><!-- /.modal-footer -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->

</div><!-- /.modal --><?php /**PATH /var/www/html/resources/views/livewire/dashboard/instagram/faq.blade.php ENDPATH**/ ?>