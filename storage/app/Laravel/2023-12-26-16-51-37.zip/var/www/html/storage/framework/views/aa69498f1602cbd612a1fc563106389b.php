<div>
    <form wire:submit>

        <div class="callout callout-info" role="alert">
            Ingrese a continuación su número de whatsapp incluyendo el código país. Ej: 59812345678
        </div>

        <!-- whatsapp -->
        <div class="mb-3">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'form.whatsapp','label' => 'Número de Whatsapp','type' => 'number','wire:model.blur' => 'form.whatsapp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'form.whatsapp','label' => 'Número de Whatsapp','type' => 'number','wire:model.blur' => 'form.whatsapp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div><!-- ./whatsapp -->


        <a href="https://wa.me/+<?php echo e($form->whatsapp); ?>" target="_blank" class="btn btn-ghost-success float-end" type="button">
            <svg class="icon">
                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/brand.svg#cib-whatsapp')); ?>"></use>
            </svg>
            Probar
        </a>

    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/settings/update-whatsapp.blade.php ENDPATH**/ ?>