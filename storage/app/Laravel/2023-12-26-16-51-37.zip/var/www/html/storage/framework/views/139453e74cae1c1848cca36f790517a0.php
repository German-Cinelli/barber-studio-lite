<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.employees')); ?>">Empleados</a></li>
        <li class="breadcrumb-item active"><span>Editar</span></li>
    <?php $__env->stopSection(); ?>

    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <i class="cil-check-circle"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    <div class="row">

        <div class="col-sm-12 col-md-6 col-lg-8">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Empleado</strong>
                </div>

                <div class="card-body">

                    <div class="my-3">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.employees.update-status', ['employee' => $employee]);

$__html = app('livewire')->mount($__name, $__params, 'BGKBR5f', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.employees.update-employee', ['employee' => $employee]);

$__html = app('livewire')->mount($__name, $__params, '4S074P2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Datos personales</strong>
                </div>

                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.personal-information.update-personal-information', ['employee' => $employee]);

$__html = app('livewire')->mount($__name, $__params, 'nESaddW', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

        </div>

        <div class="col-sm-12 col-md-6 col-lg-4">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Horario laboral</strong>
                </div>

                <div class="card-body">

                    <div class="callout callout-primary">
                        A continuación indique el horario laboral del empleado.
                    </div>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.schedules.list-schedules', ['employee' => $employee,'lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, '0w7y7eG', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Redes sociales</strong>
                </div>

                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.employee-social.create-employee-social', ['employee' => $employee]);

$__html = app('livewire')->mount($__name, $__params, '7IfG5Tl', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.employee-social.list-employee-social', ['employee' => $employee->id]);

$__html = app('livewire')->mount($__name, $__params, 'XOdDcPM', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employee-edit-component.blade.php ENDPATH**/ ?>