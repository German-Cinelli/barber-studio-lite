<div class="table-responsive">

    <div x-data="{ darkMode: false }">

        <div class="mb-3">
            <input type="checkbox" class="form-check-input" x-model="darkMode" id="toggleDarkMode">
            <label for="toggleDarkMode">Modo Oscuro</label>
        </div>

        <table class="table align-middle" :class="{ 'table': true, 'table-default': !darkMode, 'table-dark': darkMode }">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div wire:key="<?php echo e($sponsor->id); ?>">
                        <tr>
                            <th scope="row">
                                <img src="<?php echo e(asset($this->small('storage/sponsors/', $sponsor->image))); ?>" <?php if($sponsor->trashed()): ?> style="filter: grayscale(85%)" <?php endif; ?> loading="lazy">
                            </th>
                            <td>
                                <?php echo $sponsor->trashed() ? '<del>' . $sponsor->name . '</del>' : $sponsor->name; ?>

                            </td>
                            <td>
                                <!--[if BLOCK]><![endif]--><?php if($sponsor->trashed()): ?>
                                    <button wire:click="restore(<?php echo e($sponsor->id); ?>)" class="btn btn-ghost-success" type="button" title="Restaurar">
                                        <i class="cil-recycle"></i>
                                    </button>
                                <?php else: ?>
                                    <div class="btn-group" role="group" aria-label="Default button group">
                                        <button @click="$dispatch('edit-sponsor', { sponsor: '<?php echo e($sponsor->id); ?>' })" class="btn btn-ghost-warning" type="button" title="Editar" data-coreui-toggle="modal" data-coreui-target="#modal-update">
                                            <svg class="icon">
                                                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                            </svg>
                                        </button>
                                        <button wire:click="delete(<?php echo e($sponsor->id); ?>)" class="btn btn-ghost-danger" type="button" title="Eliminar">
                                            <svg class="icon">
                                                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                                            </svg>
                                        </button>
                                    </div>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            Sin resultados <!--[if BLOCK]><![endif]--><?php if($this->search): ?>para la buśqueda <strong><?php echo e($this->search); ?></strong><?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <div>
            <?php echo e($sponsors->links()); ?>

        </div>

    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/sponsors/list-sponsors.blade.php ENDPATH**/ ?>