<div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
        <i id="toastType" class="me-1"></i>
        <strong id="toastTitle" class="me-auto"></strong>
        <small>Hace un momento</small>
        <button type="button" class="btn-close" data-coreui-dismiss="toast" aria-label="Close"></button>
    </div>
    <div id="toastBody" class="toast-body"></div>
</div>
<?php /**PATH /var/www/html/resources/views/partials/toast-notification.blade.php ENDPATH**/ ?>