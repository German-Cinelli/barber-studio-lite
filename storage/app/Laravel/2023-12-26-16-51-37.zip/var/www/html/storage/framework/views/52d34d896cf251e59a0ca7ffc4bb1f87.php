<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.orders')); ?>">Tickets</a></li>
        <li class="breadcrumb-item active"><span>Ver</span></li>
    <?php $__env->stopSection(); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.orders.show-order', ['order' => $order]);

$__html = app('livewire')->mount($__name, $__params, 'TAd2qTH', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/order-show-component.blade.php ENDPATH**/ ?>