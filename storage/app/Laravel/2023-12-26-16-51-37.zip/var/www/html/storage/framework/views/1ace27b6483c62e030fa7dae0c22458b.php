<div class="accordion-item">
    <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-coreui-toggle="collapse" data-coreui-target="#collapse<?php echo e($schedule->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($schedule->id); ?>">
            <i class="<?php echo e($schedule->status ? 'cil-check-circle text-success' : 'cil-x text-danger'); ?> me-1"></i>
            <?php echo e($schedule->getDayName($schedule->weekday)); ?>

        </button>
    </h2>
    <div id="collapse<?php echo e($schedule->id); ?>" class="accordion-collapse collapse" data-coreui-parent="#accordionExample">
        <div class="accordion-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.schedules.update-status', ['schedule' => $schedule]);

$__html = app('livewire')->mount($__name, $__params, 'atVKrPQ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/schedules/show-schedule.blade.php ENDPATH**/ ?>