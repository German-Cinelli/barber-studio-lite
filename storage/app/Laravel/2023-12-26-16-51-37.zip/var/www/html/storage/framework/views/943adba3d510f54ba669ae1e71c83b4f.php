<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th scope="col">Nombre</th>
                <th scope="col">Slug <i class="cil-info text-info" title="URL en la cual se podrán visualizar todos los productos relacionados a una categoría."></i></th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($category->id); ?>">
                    <tr>
                        <td>
                            <?php echo $category->trashed() ? '<del>' . $category->name . '</del>' : $category->name; ?>

                        </td>
                        <td><code>/<?php echo e($category->slug); ?></code></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($category->trashed()): ?>
                                <button wire:click="restore(<?php echo e($category->id); ?>)" class="btn btn-ghost-success" type="button" title="Restaurar">
                                    <i class="cil-recycle"></i>
                                </button>
                            <?php else: ?>
                                <div class="btn-group" role="group" aria-label="Default button group">
                                    <button @click="$dispatch('edit-category', { category: '<?php echo e($category->id); ?>' })" class="btn btn-ghost-warning" type="button" title="Editar" data-coreui-toggle="modal" data-coreui-target="#modal-update">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                        </svg>
                                    </button>
                                    <button @click="$dispatch('delete-category', { id: '<?php echo e($category->id); ?>', name: '<?php echo e($category->name); ?>' })" class="btn btn-ghost-danger" type="button" title="Eliminar">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                                        </svg>
                                    </button>
                                </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">
                        Sin resultados <!--[if BLOCK]><![endif]--><?php if($this->search): ?>para la buśqueda <strong><?php echo e($this->search); ?></strong><?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($categories->links()); ?>

    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="liveToast2" class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-coreui-autohide="false">
            <div class="toast-body">
                <span id="toastQuestion"></span>
                <div class="mt-2 pt-2 border-top">
                    <button type="button" wire:click="delete($event.target.getAttribute('data-category-id'))" id="btn-delete-category" class="btn btn-danger btn-sm text-white">Eliminar</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-coreui-dismiss="toast">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            window.addEventListener('delete-category', event => {
                var id = event.detail.id
                var name = event.detail.name

                const toastLiveExample = document.getElementById('liveToast2')

                const deleteButton = toastLiveExample.querySelector('#btn-delete-category');
                deleteButton.setAttribute('data-category-id', id);

                toastQuestion.textContent = `¿Deseas eliminar *${name}*?`

                const toast = new coreui.Toast(toastLiveExample)
                toast.show()
            });
        </script>
    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/categories/list-categories.blade.php ENDPATH**/ ?>