<div>
    <p>Estado</p>
    <div class="form-check form-switch">
        <input wire:change="changeStatus" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault<?php echo e($schedule->id); ?>" <?php if($schedule->status): ?> checked <?php endif; ?>>
        <label for="">¿Trabaja éste día?</label>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/schedules/update-status.blade.php ENDPATH**/ ?>