<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Sponsors</span></li>
    <?php $__env->stopSection(); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sponsors.create-sponsor', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'j1g9fJR', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sponsors.update-sponsor', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'iO5aLgG', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Listado de patrocinadores</strong>
            <button class="btn btn-sm btn-primary float-end" type="button" data-coreui-toggle="modal" data-coreui-target="#modal-create">
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                </svg>
                Nuevo
            </button>
        </div>

        <div class="card-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.search-component', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'NgiljZ7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sponsors.list-sponsors', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'CUNEPgI', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/sponsor-component.blade.php ENDPATH**/ ?>