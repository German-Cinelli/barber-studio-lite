<div>
    <label class="form-check-label" for="flexSwitchCheckDefault">
        <!--[if BLOCK]><![endif]--><?php if($status): ?>
        <svg class="icon text-success">
            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-circle')); ?>"></use>
        </svg>
        Disponible
        <?php else: ?>
        <svg class="icon text-danger">
            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')); ?>"></use>
        </svg>
        Inactivo
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </label>

    <div class="float-end" title="Modificar estado">
        <form wire:submit="save">
            <div class="form-check form-switch">
                <input wire:change="changeStatus" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" <?php if($status): ?> checked <?php endif; ?>>
            </div>
        </form>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employees/update-status.blade.php ENDPATH**/ ?>