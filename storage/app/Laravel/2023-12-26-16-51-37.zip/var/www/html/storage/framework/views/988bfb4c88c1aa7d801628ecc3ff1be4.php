<div class="float-end">
        <div class="btn-add-service avatar avatar-sm text-white" data-coreui-toggle="dropdown" aria-expanded="false">
            <img class="avatar-img" src="<?php echo e(asset('coreui/assets/img/plus.png')); ?>" alt="">
        </div>
        <ul class="dropdown-menu" style="max-height: 250px; overflow-y: auto" data-coreui-toggle="auto-dropdown">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li wire:key="<?php echo e($service->id); ?>">
                    <a wire:click="addService(<?php echo e($service->id); ?>)" class="dropdown-item" href="javascript:void(0)">
                        <?php echo e($service->item->name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </ul>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointment-service/create-appointment-service.blade.php ENDPATH**/ ?>