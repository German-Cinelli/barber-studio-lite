<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Tipo</th>
                <th scope="col">Cliente</th>
                <th scope="col" width="20%">Servicios</th>
                <th scope="col">Empleado</th>
                <th scope="col">Fecha</th>
                <th scope="col">Estado</th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($appointment->id); ?>">
                    <tr>
                        <th scope="row"><?php echo e($appointment->id); ?></th>
                        <td>
                            <span class="badge me-1 bg-<?php echo e($appointment->type->bg_color); ?>">
                                <?php echo e($appointment->type->name); ?>

                            </span>
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($appointment->type == 'local'): ?>
                                <?php echo e($appointment->name); ?>

                            <?php else: ?>
                                <a href="#">
                                    <?php echo e($appointment->customer->user->name); ?>

                                </a>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointment->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="avatar" title="<?php echo e($service->item->name); ?>">
                                    <img class="avatar-img" src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>" alt="<?php echo e($service->item->name); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($appointment->employee): ?>
                                <div class="avatar">
                                    <img class="avatar-img" src="<?php echo e(asset($this->verySmall('storage/employees/', $appointment->employee->image))); ?>" alt="<?php echo e($appointment->employee->name); ?>">
                                    <?php echo e($appointment->employee->name); ?>

                                </div>
                            <?php else: ?>
                                Sin especificar.
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <?php echo e(\Carbon\Carbon::parse($appointment->start_time)->format('d-m-Y H:i')); ?>

                        </td>
                        <td>
                            <span class="badge me-1 bg-<?php echo e($appointment->status->bg_color); ?>"><?php echo e($appointment->status->name); ?></span>
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($appointment->status_id != 1): ?>
                            <div class="btn-group" role="group" aria-label="Default button group">
                                <!--<button @click="$dispatch('edit-appointment', { appointment: '<?php echo e($appointment->id); ?>' })" class="btn btn-ghost-warning" type="button" title="Editar" data-coreui-toggle="modal" data-coreui-target="#modal-update">
                                    <svg class="icon">
                                        <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                    </svg>
                                </button>-->
                                <button @click="$dispatch('delete-appointment', { id: <?php echo e($appointment->id); ?> })" class="btn btn-ghost-danger" type="button" title="Cancelar">
                                    <svg class="icon">
                                        <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                                    </svg>
                                </button>
                            </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">
                        Sin resultados <!--[if BLOCK]><![endif]--><?php if($this->search): ?>para la buśqueda <strong><?php echo e($this->search); ?></strong><?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($appointments->links()); ?>

    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="liveToast2" class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-coreui-autohide="false">
            <div class="toast-body">
                <span id="toastQuestion"></span>
                <div class="mt-2 pt-2 border-top">
                    <button type="button" wire:click="cancel($event.target.getAttribute('data-appointment-id'))" id="btn-delete-appointment" class="btn btn-danger btn-sm text-white">Cancelar agenda</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-coreui-dismiss="toast">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            window.addEventListener('delete-appointment', event => {
                var id = event.detail.id

                const toastLiveExample = document.getElementById('liveToast2')

                const deleteButton = toastLiveExample.querySelector('#btn-delete-appointment');
                deleteButton.setAttribute('data-appointment-id', id);

                toastQuestion.textContent = `¿Deseas cancelar la agenda N° ${id}?`

                const toast = new coreui.Toast(toastLiveExample)
                toast.show()
            });
        </script>
    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointments/list-appointments.blade.php ENDPATH**/ ?>