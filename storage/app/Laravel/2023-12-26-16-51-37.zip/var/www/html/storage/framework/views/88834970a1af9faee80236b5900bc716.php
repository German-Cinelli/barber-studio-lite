<div class="col-lg-6 ps-3 d-none d-md-block">
    <?php echo $embedded_content_map; ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/frontend/settings/embedded-content-map.blade.php ENDPATH**/ ?>