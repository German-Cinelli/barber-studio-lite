<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>

                <th scope="col">Categoría</th>
                <th scope="col">Precio</th>
                <th scope="col">Stock</th>
                <th scope="col">Descripción</th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($product->id); ?>">
                    <tr>
                        <th scope="row">
                            <!--[if BLOCK]><![endif]--><?php if($product->item->image): ?>
                                <div>
                                    <img src="<?php echo e(asset($this->verySmall('storage/items/', $product->item->image))); ?>" loading="lazy">
                                </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </th>
                        <td>
                            <?php echo $product->item->status ? $product->item->name : '<del>' . $product->item->name . '</del>'; ?>

                        </td>

                        <td><?php echo e($product->item->category->name); ?></td>
                        <td><?php echo e($product->item->price); ?></td>
                        <td>
                            <h5>
                                <!--[if BLOCK]><![endif]--><?php switch($product->stock):
                                    case (0): ?>
                                        <span class="badge bg-danger">
                                            <?php echo e($product->stock); ?>

                                        </span>
                                        <?php break; ?>

                                    <?php case ($product->stock > 0 && $product->stock < 5): ?>
                                        <span class="badge bg-warning">
                                            <?php echo e($product->stock); ?>

                                        </span>
                                        <?php break; ?>

                                    <?php case ($product->stock >= 5): ?>
                                        <span class="badge bg-success">
                                            <?php echo e($product->stock); ?>

                                        </span>
                                        <?php break; ?>

                                    <?php default: ?>

                                <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                            </h5>
                        </td>
                        <td><?php echo e($product->item->description); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Default button group">
                                <a href="<?php echo e(route('dashboard.products.edit', $product->id)); ?>" class="btn btn-ghost-warning" type="button" title="Editar">
                                    <i class="cil-pencil"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">
                        Sin resultados <!--[if BLOCK]><![endif]--><?php if($this->search): ?>para la buśqueda <strong><?php echo e($this->search); ?></strong><?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($products->links()); ?>

    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/products/list-products.blade.php ENDPATH**/ ?>