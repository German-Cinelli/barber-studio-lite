<div class="modal fade" tabindex="-1" id="modal-instagram-feed-faq">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form wire:submit="save">
                <div class="modal-header">
                    <h5 class="modal-title">¿Cómo inserto contenido?</h5>
                    <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <p class="lead">
                        Para hacerlo, dirígase a la publicación de Instagram que desea insertar al sitio
                        y presione sobre el ícono <i class="cil-options"></i> que se encuentra en la esquina superior derecha.
                    </p>
                    <p class="lead">Se desplegará un menú similar al siguiente:</p>
                    <ul>
                        <li>Reportar</li>
                        <li>Ir a la publicación</li>
                        <li>Compartir en...</li>
                        <li>Copiar enlace</li>
                        <li>Insertar</li>
                        <li>Información sobre esta cuenta</li>
                    </ul>
                    <p class="lead">
                        Luego de presionar sobre la opción <strong>Insertar</strong>, se despliega un
                        botón para copiar el código de inserción.
                        Tras copiarlo volvemos aquí y añadimos el contenido embebido.
                    </p>

                    <div class="callout callout-info">
                        Se recomienda marcar la opción <strong>incluir pie de foto</strong> para
                            publicaciones con descripción no muy extensas.
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Cerrar</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/instagram/faq-modal.blade.php ENDPATH**/ ?>