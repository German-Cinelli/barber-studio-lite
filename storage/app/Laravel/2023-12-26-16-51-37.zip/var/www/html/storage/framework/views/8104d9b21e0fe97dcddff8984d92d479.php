<div>
    <!--[if BLOCK]><![endif]--><?php if($sponsors->isNotEmpty()): ?>
        <div id="oc-clients" class="owl-carousel owl-carousel-full image-carousel carousel-widget topmargin-lg mb-0" data-margin="0" data-nav="false" data-pagi="false" data-autoplay="3000" data-items-xs="3" data-items-sm="3" data-items-md="5" data-items-lg="6" data-items-xl="6" data-loop="true" style="z-index: 2; padding: 30px 0; border-top: 1px solid rgba(255,255,255,0.15);">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="oc-item">
                    <a href="javascript:void(0)" title="<?php echo e($sponsor->name); ?>">
                        <img src="<?php echo e(asset($this->verySmall('storage/sponsors/', $sponsor->image))); ?>" alt="<?php echo e($sponsor->name); ?>">
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /var/www/html/resources/views/livewire/frontend/sponsors/sponsor-component.blade.php ENDPATH**/ ?>