<div class="service-container">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointment_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div wire:key="<?php echo e($appointment_service->id); ?>" class="avatar avatar-sm">
            <img class="avatar-img" src="<?php echo e(asset($this->verySmall('storage/items/', $appointment_service->service->item->image))); ?>" title="<?php echo e($appointment_service->service->item->name); ?>" alt="" loading="lazy" />
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.appointment-service.create-appointment-service', ['appointment' => $appointment,'services' => $services]);

$__html = app('livewire')->mount($__name, $__params, 'hKm4gKu', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointment-service/list-appointment-services.blade.php ENDPATH**/ ?>