<div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Slug</th>
                <th scope="col">Categoría</th>
                <th scope="col">Precio</th>
                <th scope="col">Duración <i class="cil-info text-info" title="Representado en minutos"></i></th>
                <th scope="col">Descripción</th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($service->id); ?>">
                    <tr>
                        <th scope="row">
                            <!--[if BLOCK]><![endif]--><?php if($service->item->image): ?>
                                <div>
                                    <img src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>" alt="Imagen de ">
                                </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </th>
                        <td>
                            <?php echo $service->item->status ? $service->item->name : '<del>' . $service->item->name . '</del>'; ?>

                        </td>
                        <td><code>/<?php echo e($service->item->slug); ?></code></td>
                        <td><?php echo e($service->item->category->name); ?></td>
                        <td><?php echo e($service->item->price); ?></td>
                        <td><?php echo e($service->duration_time); ?></td>
                        <td><?php echo e($service->item->description); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Default button group">
                                <a href="<?php echo e(route('dashboard.services.edit', $service->id)); ?>" class="btn btn-outline-warning" type="button" title="Editar">
                                    <i class="cil-pencil"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        Sin resultados.
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($services->links()); ?>

    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="liveToast2" class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-coreui-autohide="false">
            <div class="toast-body">
                <span id="toastQuestion"></span>
                <div class="mt-2 pt-2 border-top">
                    <button type="button" wire:click="disable($event.target.getAttribute('data-item-id'))" id="btn-delete-item" class="btn btn-danger btn-sm text-white">Desactivar</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-coreui-dismiss="toast">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
    <script>
        window.addEventListener('disable-item', event => {
            var id = event.detail.id
            var name = event.detail.name

            const toastLiveExample = document.getElementById('liveToast2')

            const deleteButton = toastLiveExample.querySelector('#btn-delete-item');
            deleteButton.setAttribute('data-item-id', id);

            toastQuestion.textContent = `¿Deseas eliminar *${name}*?`

            const toast = new coreui.Toast(toastLiveExample)
            toast.show()
        });
    </script>

    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/services/list-service.blade.php ENDPATH**/ ?>