<div class="row">

    <div class="text-end">
        <button class="btn btn-sm btn-outline-primary rounded-0" type="button" data-coreui-toggle="modal" data-coreui-target="#modal-create">
            <svg class="icon">
                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
            </svg>
        </button>
    </div>

    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div wire:key="<?php echo e($appointment->id); ?>" class="col-sm-6 col-md-12 col-lg-4 my-3">
            <div class="card">
                <div class="card-body">

                    <div class="ribbon-wrapper ribbon-sm">
                        <div class="ribbon bg-<?php echo e($appointment->type->bg_color); ?>">
                            <small class="text-white"><?php echo e($appointment->type->name); ?></small>
                        </div>
                    </div>

                    <div class="text-medium-emphasis small text-uppercase fw-semibold text-center mt-3">
                        <i class="cil-user"></i>
                        <?php echo e($appointment->name); ?>

                    </div>

                    <div class="text-center fs-6 py-3">
                        <small>
                            <svg class="icon">
                                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-clock')); ?>"></use>
                            </svg>
                            <?php echo e(\Carbon\Carbon::parse($appointment->start_time)->format('H:i')); ?>

                        </small>
                    </div>



                    <div class="text-center">

                        <div class="btn-group">

                            <div class="avatar avatar-md" data-coreui-toggle="dropdown" aria-expanded="false">
                                <div x-data="{ hover: false }" class="avatar bg-light text-dark"
                                    data-coreui-toggle="dropdown" aria-expanded="false"
                                    <?php if(in_array($appointment->status_id, [1, 2, 3])): ?>
                                        @mouseover="hover = true"
                                        @mouseleave="hover = false">
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                                    <!--[if BLOCK]><![endif]--><?php if($appointment->employee): ?>
                                    <div style="position: relative;">

                                            <i class="cil-transfer text-warning" style="cursor: pointer" title="Cambiar de empleado" x-show="hover"></i>

                                            <span x-show="!hover">
                                                <img class="avatar-img"
                                                    src="<?php echo e(asset($this->verySmall('storage/employees/', $appointment->employee->image))); ?>"
                                                    title="<?php echo e($appointment->employee->name); ?>" alt=""
                                                    <?php if(in_array($appointment->status_id, [1, 2, 3])): ?>
                                                    loading="lazy" @mouseover="hover = true" @mouseleave="hover = false"
                                                    style="opacity: 1; transition: opacity 0.3s ease-in-out;"
                                                    <?php endif; ?>
                                                />
                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <i class="cil-user-plus text-success" style="cursor: pointer" title="Añadir empleado" x-show="hover"></i>
                                        <span x-show="!hover">?</span> <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if(in_array($appointment->status_id, [1, 2, 3])): ?>
                                        <ul class="dropdown-menu" style="">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a wire:click="changeEmployee(<?php echo e($appointment->id); ?>, <?php echo e($employee->id); ?>)"
                                                        class="dropdown-item <?php echo e($appointment->employee_id == $employee->id ? 'disabled' : ''); ?>"
                                                        href="#">
                                                        <img src="<?php echo e(asset($this->small('storage/employees/', $employee->image))); ?>"
                                                            style="border-radius: 50%" alt="" width="36px"
                                                            loading="lazy">
                                                        <?php echo e($employee->name); ?>

                                                        <!--[if BLOCK]><![endif]--><?php if($employee->id == $appointment->employee_id): ?>
                                                            <i class="cil-check text-success"></i>
                                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                        </ul>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <button
                                    class="btn btn-ghost-<?php echo e($appointment->status->bg_color); ?> rounded-0 btn-sm dropdown-toggle"
                                    type="button" data-coreui-toggle="dropdown" aria-expanded="false">

                                    <?php echo e($appointment->status->name); ?>

                                </button>
                                <ul class="dropdown-menu" style="">
                                    <!--[if BLOCK]><![endif]--><?php switch($appointment->status_id):
                                        case (1): ?>
                                            <li>
                                                <a class="dropdown-item" href="#">
                                                    <i class="cil-x-alt text-danger"></i>
                                                    Ocultar
                                                </a>
                                            </li>
                                        <?php break; ?>

                                        <?php case (2): ?>
                                            <li>
                                                <a class="dropdown-item" href="#">
                                                    <i class="cil-check-alt text-success"></i>
                                                    Confirmar asistencia
                                                </a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a wire:click="cancelAppointment(<?php echo e($appointment->id); ?>)" class="dropdown-item" href="javascript:void(0)">
                                                    <i class="cil-x text-danger"></i>
                                                    Cancelar agenda
                                                </a>
                                            </li>
                                        <?php break; ?>

                                        <?php case (3): ?>
                                            <!--[if BLOCK]><![endif]--><?php if($appointment->employee): ?>
                                                <li>
                                                    <a class="dropdown-item"
                                                        wire:click="attendCustomer(<?php echo e($appointment->id); ?>, <?php echo e($appointment->employee_id); ?>, '<?php echo e($appointment->employee->name); ?>')"
                                                        href="javascript:void(0)">
                                                        <i class="cil-chevron-right text-success"></i>
                                                        Atenderse con <?php echo e($appointment->employee->name); ?>

                                                    </a>
                                                </li>
                                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a wire:click="cancelAppointment(<?php echo e($appointment->id); ?>)" class="dropdown-item" href="javascript:void(0)">
                                                    <i class="cil-x text-danger"></i>
                                                    Cancelar agenda
                                                </a>
                                            </li>
                                        <?php break; ?>

                                        <?php case (4): ?>
                                            <li>
                                                <a class="dropdown-item" href="#">
                                                    <i class="cil-check-alt text-success"></i>
                                                    Finalizar consulta
                                                </a>
                                            </li>
                                        <?php break; ?>

                                        <?php default: ?>
                                    <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>

                        </div>

                        <hr>

                        <div class="service-container">

                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointment->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:key="<?php echo e($service->id); ?>" class="avatar avatar-sm">
                                    <div x-data="{ isHovered: false }" @mouseover="isHovered = true"
                                        @mouseout="isHovered = false" wire:key="<?php echo e($service->id); ?>"
                                        class="avatar avatar-sm relative">
                                        <img class="avatar-img"
                                            src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>"
                                            title="<?php echo e($service->item->name); ?>" alt="" loading="lazy" />
                                        <span x-show="isHovered" class="avatar-status"
                                            title="Quitar <?php echo e($service->item->name); ?>"
                                            wire:click="deleteService(<?php echo e($appointment->id); ?>, <?php echo e($service->id); ?>)"
                                            style="cursor: pointer">
                                            <i class="cil-x bg-danger text-white"
                                                style="font-size: 1.1em; border-radius: 50%"></i>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

                            <div class="float-end">

                                <div class="btn-add-service avatar avatar-sm text-white" data-coreui-toggle="dropdown" aria-expanded="false">
                                    <img class="avatar-img" src="<?php echo e(asset('coreui/assets/img/plus.png')); ?>" alt="">
                                </div>

                                <ul class="dropdown-menu" style="max-height: 250px; overflow-y: auto"
                                    data-coreui-toggle="auto-dropdown">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li wire:key="<?php echo e($service->id); ?>">
                                            <a wire:click="addService(<?php echo e($appointment->id); ?>, <?php echo e($service->id); ?>)"
                                                class="dropdown-item" href="javascript:void(0)">
                                                <?php echo e($service->item->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container">
                    <div class="callout callout-primary">
                        Sin resultados.
                    </div>
                </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointments/list-appointments-cards.blade.php ENDPATH**/ ?>