<div>
    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Configuración</span></li>
    <?php $__env->stopSection(); ?>

    <div class="row">

        <div class="col-sm-12 col-md-6 col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <strong># Configuración</strong>
                </div>

                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-setting', ['setting' => $setting]);

$__html = app('livewire')->mount($__name, $__params, 'rj4avJg', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Whatsapp</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-whatsapp', ['whatsapp' => $setting->whatsapp]);

$__html = app('livewire')->mount($__name, $__params, 'knWNaV8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

        </div>

        <div class="col-sm-12 col-md-6 col-lg-4">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Logo</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-logo', ['logo' => $setting->logo]);

$__html = app('livewire')->mount($__name, $__params, '1Y80aDz', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Banner</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-banner', ['banner' => $setting->banner]);

$__html = app('livewire')->mount($__name, $__params, 'Uw1sa4j', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Mapa</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-embedded-content-map', ['embeddedContentMap' => $setting->embedded_content_map,'embedded_content_map' => $setting->embedded_content_map]);

$__html = app('livewire')->mount($__name, $__params, 'GOpNmyJ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

        </div>

    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/settings-component.blade.php ENDPATH**/ ?>