<div>
    <div class="accordion" id="accordionExample">

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div wire:key="<?php echo e($schedule->id); ?>">

            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-coreui-toggle="collapse" data-coreui-target="#collapse<?php echo e($schedule->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($schedule->id); ?>">
                        <i class="<?php echo e($schedule->status ? 'cil-check-circle text-success' : 'cil-minus text-danger'); ?> me-1"></i>
                        <?php echo e($schedule->getDayName($schedule->weekday)); ?>


                        <div class="badge text-bg-light ms-2">
                            <small>
                                <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $schedule->start_time)->format('H:i')); ?> -
                                <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $schedule->end_time)->format('H:i')); ?>

                            </small>
                        </div>

                    </button>
                </h2>
                <div wire:ignore id="collapse<?php echo e($schedule->id); ?>" class="accordion-collapse collapse" data-coreui-parent="#accordionExample">
                    <div class="accordion-body">

                        <div class="form-check form-switch">
                            <input wire:change="changeStatus(<?php echo e($schedule->id); ?>)" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault<?php echo e($schedule->id); ?>" <?php if($schedule->status): ?> checked <?php endif; ?>>
                            <label for="">¿Trabaja éste día?</label>
                        </div>

                        <div class="mt-3">
                            <label for="">Hora de entrada</label>

                            <div class="row">
                                <div class="col-10">
                                    <input type="time" wire:model="startTimes.<?php echo e($schedule->id); ?>" class="form-control">
                                </div>
                                <div class="col-2">
                                    <button type="button" wire:click="updateStartTime(<?php echo e($schedule->id); ?>)" class="btn btn-ghost-primary">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-check-alt')); ?>"></use>
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <hr>

                            <label for="">Hora de salida</label>
                            <div class="row">
                                <div class="col-10">
                                    <input type="time" wire:model="endTimes.<?php echo e($schedule->id); ?>" class="form-control">
                                </div>
                                <div class="col-2">
                                    <button type="button" wire:click="updateEndTime(<?php echo e($schedule->id); ?>)" class="btn btn-ghost-primary">
                                        <i class="cil-check-alt"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/schedules/list-schedules.blade.php ENDPATH**/ ?>