<div wire:ignore.self class="offcanvas offcanvas-end" data-coreui-scroll="true" tabindex="-1" id="offcanvasWithBothOptions"
    aria-labelledby="offcanvasWithBothOptionsLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Tickets</h5>
        <button type="button" class="btn-close" data-coreui-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">

        <div class="row">

            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body">

                            <div class="text-medium-emphasis fs-5 fw-semibold text-center">
                                <svg class="icon icon-xl">
                                    <use
                                        xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>">
                                    </use>

                                </svg>
                                <?php echo e($order->name); ?>

                            </div>

                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-body p-3 d-flex align-items-center">
                                    <div class="text-white me-2">
                                        <div class="avatar avatar-md">
                                            <img class="avatar-img rounded-0"
                                                src="<?php echo e(asset($this->verySmall('storage/items/', $item->item->image))); ?>"
                                                loading="lazy">
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="fs-6 fw-semibold text-info">
                                            <button wire:click="decrementQuantity(<?php echo e($item); ?>)"
                                                class="btn btn-sm btn-ghost-primary">
                                                <svg class="icon">
                                                    <use
                                                        xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-minus')); ?>">
                                                    </use>
                                                </svg>
                                            </button>

                                            x<?php echo e($item->quantity); ?>


                                            <button wire:click="incrementQuantity(<?php echo e($item); ?>, <?php echo e($item->quantity); ?>)"
                                                class="btn btn-sm btn-ghost-primary">
                                                <svg class="icon">
                                                    <use
                                                        xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>">
                                                    </use>
                                                </svg>
                                            </button>
                                        </div>

                                        <div class="ms-3">
                                            <small><?php echo e($item->price); ?></small>
                                        </div>


                                        <div class="text-medium-emphasis text-uppercase fw-semibold ms-3 small">
                                            <small><?php echo e($item->item->name); ?></small>

                                            <button
                                                wire:click="deleteItemOrder(<?php echo e($item->id); ?>, <?php echo e($order->id); ?>, '<?php echo e($item->item->name); ?>')"
                                                class="btn btn-sm text-right" title="Eliminar <?php echo e($item->item->name); ?>">
                                                <svg class="icon text-danger">
                                                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-x')); ?>"></use>
                                                </svg>
                                            </button>

                                        </div>

                                    </div>

                                    <div class="fs-6 fw-semibold text-info float-end">
                                        <?php echo e($item->price * $item->quantity); ?>

                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

                            <div class="fs-5 fw-semibold text-info float-end">
                                <?php echo e(number_format($order->total, 2)); ?>

                            </div>

                            <div class="dropdown p-3">
                                <div class="text-white me-2">
                                    <div wire:click="loadItems" class="avatar bg-info" style="cursor: pointer" data-coreui-toggle="dropdown" aria-expanded="true">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                                        </svg>
                                    </div>

                                    <ul wire:ignore.self class="dropdown-menu" data-coreui-toggle="auto-dropdown" style="max-height: 250px; overflow-y: auto">
                                        <!--[if BLOCK]><![endif]--><?php if(!$loadedItems): ?>
                                        <li>
                                            <div class="d-flex justify-content-center">
                                                <div class="spinner-border spinner-border-sm" role="status">
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </div>
                                        </li>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li wire:key="<?php echo e($item->id); ?>">
                                                <a wire:click="addItem(<?php echo e($order->id); ?>, <?php echo e($item->id); ?>, '<?php echo e($item->name); ?>')"
                                                    class="dropdown-item" href="javascript:void(0)">
                                                    <?php echo e($item->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                    </ul>

                                </div>
                            </div>

                            <button wire:click="cancelOrder(<?php echo e($order->id); ?>)" class="btn btn-ghost-danger rounded-0" type="button" aria-pressed="true">
                                Rechazar
                                <svg class="icon">
                                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-x')); ?>"></use>
                                </svg>
                            </button>

                            <button wire:click="confirmOrder(<?php echo e($order->id); ?>)" type="button"
                                class="btn btn-ghost-success rounded-0 float-end">
                                Confirmar
                                <svg class="icon">
                                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-check-alt')); ?>"></use>
                                </svg>
                            </button>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container">
                    <div class="callout callout-primary">
                        Sin resultados.
                    </div>
                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        </div>

    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/orders/list-orders-in-backdrop.blade.php ENDPATH**/ ?>