<div>
    <form wire:submit="save">

        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
            <label class="form-check-label" for="flexSwitchCheckDefault">Default switch checkbox input</label>
        </div>

    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/items/change-status-item.blade.php ENDPATH**/ ?>