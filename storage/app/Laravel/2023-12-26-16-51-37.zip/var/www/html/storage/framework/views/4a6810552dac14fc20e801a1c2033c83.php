<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imprimir</title>
    <link href="<?php echo e(asset('coreui/css/style.css')); ?>" rel="stylesheet">
</head>

<body onload="window.print()">
    <div>
        <div class="row mb-4">

            <div class="col-2">
                <div>
                    <img src="<?php echo e(asset($this->small('storage/logo/', $settings->logo))); ?>" alt="" width="96px" loading="lazy">
                </div>
            </div>

            <div class="col-3">
                <div>
                    <?php echo e($settings->company_name); ?>

                </div>
                <div>
                    <?php echo e($settings->address); ?>, <?php echo e($settings->location); ?>

                </div>
                <div>
                    <?php echo e($settings->phone); ?>

                </div>

            </div>

            <div class="col-7 text-end">
                <div>
                    <strong>Ticket #<?php echo e($order->id); ?></strong>
                </div>
                <div>
                    <?php echo e(date('d-m-Y H:i')); ?>

                </div>
            </div>

        </div>

        <!-- /.row-->
        <div class="table-responsive-sm mt-3">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th>Item</th>
                        <th class="center">Precio</th>
                        <th class="right">Cantidad</th>
                        <th class="right">Importe</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="center"><?php echo e(++$key); ?></td>
                            <td class="left"><?php echo e($item->item->name); ?></td>
                            <td class="center"><?php echo e($item->price); ?></td>
                            <td class="right">x<?php echo e($item->quantity); ?></td>
                            <td class="right"><?php echo e($item->price * $item->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-lg-4 col-sm-5 ms-auto">
                <table class="table table-clear">
                    <tbody>
                        <tr>
                            <td class="left">
                                <strong>Subtotal</strong>
                            </td>
                            <td class="right"><?php echo e($order->subtotal); ?></td>
                        </tr>
                        <tr>
                            <td class="left">
                                <strong>Descuento</strong>
                            </td>
                            <td class="right"><?php echo e($order->discount); ?></td>
                        </tr>
                        <tr>
                            <td class="left">
                                <strong>Total</strong>
                            </td>
                            <td class="right"><strong><?php echo e($order->total); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH /var/www/html/resources/views/livewire/dashboard/order-print-component.blade.php ENDPATH**/ ?>