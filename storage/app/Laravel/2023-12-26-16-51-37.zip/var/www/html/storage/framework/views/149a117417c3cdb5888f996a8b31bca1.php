<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.products')); ?>">Productos</a></li>
        <li class="breadcrumb-item active"><span>Editar</span></li>
    <?php $__env->stopSection(); ?>

    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <svg class="icon">
                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
            </svg>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    <div class="row">

        <div class="col-sm-12 col-md-6 col-lg-8">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Información</strong>
                </div>

                <div class="card-body">
                    <div class="my-3">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-status', ['item' => $product->item]);

$__html = app('livewire')->mount($__name, $__params, 'g8VSku3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-item', ['item' => $product->item,'categories' => $categories]);

$__html = app('livewire')->mount($__name, $__params, 'BsjejG9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Detalles</strong>
                </div>

                <div class="card-body">

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.products.update-long-description', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'kLFy6fU', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                </div>
            </div>

        </div>

        <div class="col-sm-12 col-md-6 col-lg-4">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Imagen principal</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-image', ['item' => $product->item]);

$__html = app('livewire')->mount($__name, $__params, 'keTaOhB', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Producto</strong>
                </div>

                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.products.update-product', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'kMG7Sv9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Galería</strong>
                </div>

                <div class="card-body">

                    <div class="row">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.images.list-images', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'btwz1mk', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>

                    <div class="row">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.images.create-image', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'QMqYAlF', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/product-edit-component.blade.php ENDPATH**/ ?>