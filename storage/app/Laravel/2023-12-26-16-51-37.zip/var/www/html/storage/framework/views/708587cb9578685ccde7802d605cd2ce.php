<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Slug</th>
                <th scope="col">Categoría</th>
                <th scope="col">Precio</th>
                <th scope="col">Duración</th>
                <th scope="col">Descripción</th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($service->id); ?>">
                    <tr>
                        <th scope="row">
                            <!--[if BLOCK]><![endif]--><?php if($service->item->image): ?>
                                <div>
                                    <img src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>" loading="lazy">
                                </div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </th>
                        <td>
                            <?php echo $service->item->status ? $service->item->name : '<del>' . $service->item->name . '</del>'; ?>

                        </td>
                        <td><code>/<?php echo e($service->item->slug); ?></code></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($service->item->category): ?>
                                <?php echo e($service->item->category->name); ?>

                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td><?php echo e($service->item->price); ?></td>
                        <td><?php echo e($service->duration_time); ?></td>
                        <td><?php echo e($service->item->description); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Default button group">
                                <a href="<?php echo e(route('dashboard.services.edit', $service->id)); ?>" class="btn btn-ghost-warning" type="button" title="Editar">
                                    <svg class="icon">
                                        <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                    </svg>
                                </a>
                            </div>
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">
                        Sin resultados <!--[if BLOCK]><![endif]--><?php if($this->search): ?>para la buśqueda <strong><?php echo e($this->search); ?></strong><?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($services->links()); ?>

    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/services/list-services.blade.php ENDPATH**/ ?>