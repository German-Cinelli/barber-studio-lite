<?php

namespace Facades\App\Livewire\Actions\Dashboard\Service;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Livewire\Actions\Dashboard\Service\UpdateAction
 */
class UpdateAction extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Livewire\Actions\Dashboard\Service\UpdateAction';
    }
}
