<div>
    <form wire:submit="save">

        <!-- productType -->
        <div class="mb-3">
            <div class="alert alert-info" role="alert">
                <i class="cil-task"></i>
                Seleccione si corresponde a un <b>producto</b> o <b>servicio</b>.
            </div>

            <div class="form-check">
                <input wire:model.live="productType" class="form-check-input" value="product" name="productType" type="radio" id="radioProduct" disabled>
                <label class="form-check-label" for="radioProduct">
                    Producto
                </label><span class="badge badge-sm bg-danger" style="margin-left: 1em">PRO</span>
              </div>
              <div class="form-check">
                <input wire:model.live="productType" value="service" class="form-check-input" name="productType" type="radio" id="radioService">
                <label class="form-check-label" for="radioService">
                    Servicio
                </label>
            </div>
        </div><!-- ./productType -->

        <?php echo $__env->make('livewire.dashboard.items.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--[if BLOCK]><![endif]--><?php if($form->image): ?>
            <img src="<?php echo e($form->image->temporaryUrl()); ?>" width="150px">
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        <button type="submit" class="btn btn-primary float-end">
            Ingresar
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/products/create-product.blade.php ENDPATH**/ ?>