<div>
   <h1>HomeComponent</h1>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/home-component.blade.php ENDPATH**/ ?>