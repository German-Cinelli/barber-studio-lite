<div class="card mb-4">

    <div class="card-header">
        <strong>Información del ticket</strong>
    </div>

    <div class="card-body">

        <div class="row mb-4">
            <h6 class="mb-3">
                Ticket <strong>#<?php echo e($order->id); ?></strong>

                <div class="float-end">
                    <a href="<?php echo e(route('dashboard.orders.print', $order->id)); ?>" target="_blank" class="btn btn-info rounded-0 ms-auto me-1 d-print-none">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-print')); ?>"></use>
                        </svg>
                        Imprimir
                    </a>
                </div>
            </h6>

            <div>
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                </svg>
                <strong>
                    <!--[if BLOCK]><![endif]--><?php if($order->customer_id == 1): ?>
                        <?php echo e($order->customer->user->name); ?>: <?php echo e($order->name); ?>

                    <?php else: ?>
                        <?php echo e($order->name); ?>

                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </strong>
            </div>
            <div>
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-calendar')); ?>"></use>
                </svg>
                <?php echo e($order->created_at->format('d-m-Y H:i')); ?>

            </div>
            <div>
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-credit-card')); ?>"></use>
                </svg>
                Pago: <?php echo e($order->payment_status ? 'Realizado' : 'Pendiente'); ?>

            </div>

        </div><!-- /.row-->
        <div class="table-responsive-sm">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th>Item</th>
                        <th class="right">Precio</th>
                        <th class="center">Cantidad</th>
                        <th class="right">Importe</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="center"><?php echo e(++$key); ?></td>
                            <td class="left"><?php echo e($item->item->name); ?></td>
                            <td class="right"><?php echo e($item->price); ?></td>
                            <td class="center">x<?php echo e($item->quantity); ?></td>
                            <td class="right"><?php echo e($item->price * $item->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-lg-4 col-sm-5 ms-auto">
                <table class="table table-clear">
                    <tbody>
                        <tr>
                            <td class="left">
                                <strong>Subtotal</strong>
                            </td>
                            <td class="right"><?php echo e($order->subtotal); ?></td>
                        </tr>
                        <tr>
                            <td class="left">
                                <strong>Descuento</strong>
                            </td>
                            <td class="right"><?php echo e($order->discount); ?></td>
                        </tr>
                        <tr>
                            <td class="left">
                                <strong>Total</strong>
                            </td>
                            <td class="right"><strong><?php echo e($order->total); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/orders/show-order.blade.php ENDPATH**/ ?>