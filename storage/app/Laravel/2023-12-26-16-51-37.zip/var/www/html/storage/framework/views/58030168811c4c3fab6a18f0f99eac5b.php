<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Cliente</th>
                <th scope="col">Items</th>
                <th scope="col">Total</th>
                <th scope="col">Pago</th>

                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div wire:key="<?php echo e($order->id); ?>">
                    <tr>
                        <th scope="row">
                            <a href="<?php echo e(route('dashboard.orders.show', $order->id)); ?>">
                                <?php echo e($order->id); ?>

                            </a>
                        </th>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($order->customer_id == 1): ?>
                                <?php echo e($order->name); ?>

                            <?php else: ?>
                            <a href="<?php echo e(route('dashboard.customers.show', $order->customer_id)); ?>">
                                <?php echo e($order->customer->name); ?>

                            </a>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="avatar" title="<?php echo e($item->item->name); ?>">
                                    <img class="avatar-img"
                                        src="<?php echo e(asset($this->verySmall('storage/items/', $item->item->image))); ?>"
                                        alt="" loading="lazy">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <?php echo e($order->total); ?>

                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($order->payment_status): ?>
                                <span class="badge text-bg-success">Realizado</span>
                            <?php else: ?>
                                <span class="badge text-bg-warning">Pendiente</span>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>

                        <td>

                            <div class="btn-group" role="group" aria-label="Default button group">
                                <a href="<?php echo e(route('dashboard.orders.show', $order->id)); ?>" class="btn btn-ghost-info" type="button" title="Ver ticket">
                                    <svg class="icon">
                                        <use xlink:href="http://127.0.0.1/coreui/vendors/@coreui/icons/svg/free.svg#cil-search"></use>
                                    </svg>
                                </a>
                                <a href="<?php echo e(route('dashboard.orders.print', $order->id)); ?>" target="_blank" class="btn btn-ghost-dark" type="button" title="Imprimir">
                                    <svg class="icon">
                                        <use xlink:href="http://127.0.0.1/coreui/vendors/@coreui/icons/svg/free.svg#cil-print"></use>
                                    </svg>
                                </a>
                                <a href="javascript:void(0)" @click="$dispatch('delete-order', { id: <?php echo e($order->id); ?> })" class="btn btn-ghost-danger" type="button" title="Eliminar">
                                    <svg class="icon">
                                        <use xlink:href="http://127.0.0.1/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash"></use>
                                    </svg>
                                </a>
                            </div>
                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        Sin resultados
                        <!--[if BLOCK]><![endif]--><?php if($this->search): ?>
                            para la buśqueda <strong><?php echo e($this->search); ?></strong>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($orders->links()); ?>

    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="liveToast2" class="toast" role="alert" aria-live="assertive" aria-atomic="true"
            data-coreui-autohide="false">
            <div class="toast-body">
                <span id="toastQuestion"></span>
                <div class="mt-2 pt-2 border-top">
                    <button type="button" wire:click="delete($event.target.getAttribute('data-order-id'))"
                        id="btn-delete-order" class="btn btn-danger btn-sm text-white">Eliminar</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-coreui-dismiss="toast">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            window.addEventListener('delete-order', event => {
                var id = event.detail.id

                const toastLiveExample = document.getElementById('liveToast2')

                const deleteButton = toastLiveExample.querySelector('#btn-delete-order');
                deleteButton.setAttribute('data-order-id', id);

                toastQuestion.textContent = `¿Deseas eliminar el ticket #${id}?`

                const toast = new coreui.Toast(toastLiveExample)
                toast.show()
            });
        </script>
    <?php $__env->stopPush(); ?>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/orders/list-orders.blade.php ENDPATH**/ ?>