<div>
    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Instagram</span></li>
    <?php $__env->stopSection(); ?>

    <!-- modal how to insert a new feed -->
    <?php echo $__env->make('livewire.dashboard.instagram.faq-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Nuevo feed</strong>
        </div>

        <div class="card-body">

            <p class="lead">
                <a href="javascript:void(0)" style="text-decoration: none" data-coreui-toggle="modal" data-coreui-target="#modal-instagram-feed-faq">
                    ¿Cómo inserto contenido?
                </a>
            </p>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.instagram.create-instagram-feed', []);

$__html = app('livewire')->mount($__name, $__params, 'Ei018B7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Feed de instagram</strong>
        </div>

        <div class="card-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.instagram.list-instagram-feeds', []);

$__html = app('livewire')->mount($__name, $__params, 'CAGUURt', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/instagram-feed-component.blade.php ENDPATH**/ ?>