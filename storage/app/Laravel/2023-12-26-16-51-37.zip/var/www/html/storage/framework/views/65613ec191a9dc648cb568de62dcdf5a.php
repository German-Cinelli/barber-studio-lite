<section id="slider" class="slider-element slider-parallax page-section min-vh-60 min-vh-md-100 include-header">
    <div class="slider-inner" style="background: url('<?php echo e(asset($this->extraLarge('storage/banners/', $banner))); ?>') center center no-repeat; background-size: cover;">

        <div class="vertical-middle">
            <div class="text-center py-5 py-md-0">

                <!-- Slider Navigation
                ============================================= -->
                <nav class="custom-hero-nav">
                    <ul class="one-page-menu" data-easing="easeInOutExpo" data-speed="1300" data-offset="60">
                        <li class="active"><a href="#" data-href="#slider">Home</a></li>
                        <li><a href="#" data-offset="56" data-href="#service">Service</a></li>
                        <li><a href="#" data-href="#price">Price</a></li>
                        <li><a href="#" data-href="#shop">Shop</a></li>
                        <li><a href="#" data-href="#testimonial">Testimonial</a></li>
                        <li><a href="#" data-href="#contact">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>

        <div class="video-wrap">
            <div class="video-overlay" style="background: rgba(0,0,0,0.3);"></div>
        </div>

        <!-- Slider Appointment Button
        ============================================= -->
        <a href="#" class="button button-large button-color button-appointment d-none d-lg-block" data-scrollto="#contact" data-offset="62" data-easing="easeInOutExpo" data-speed="1300"><i class="icon-calendar2"></i> Agendarme</a>

        <!-- Slider Social Icons
        ============================================= -->
        <div class="slider-social d-none d-lg-block clearfix">
            <a href="https://instagram.com/semicolonweb" target="_blank" class="social-icon si-small si-borderless si-instagram">
                <i class="icon-instagram"></i>
                <i class="icon-instagram"></i>
            </a>
            <a href="https://youtube.com/semicolonweb" target="_blank" class="social-icon si-small si-borderless si-whatsapp">
                <i class="icon-whatsapp"></i>
                <i class="icon-whatsapp"></i>
            </a>
        </div>

    </div>
</section><?php /**PATH /var/www/html/resources/views/livewire/frontend/settings/banner.blade.php ENDPATH**/ ?>