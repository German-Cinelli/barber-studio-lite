<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.services')); ?>">Servicios</a></li>
        <li class="breadcrumb-item active"><span>Editar</span></li>
    <?php $__env->stopSection(); ?>

    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <i class="cil-check-circle"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    <div class="row">

        <div class="col-sm-12 col-md-6 col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <strong># Información</strong>
                </div>

                <div class="card-body">
                    <div class="my-3">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-status', ['item' => $service->item]);

$__html = app('livewire')->mount($__name, $__params, 'XWJi7K7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-item', ['item' => $service->item,'categories' => $categories]);

$__html = app('livewire')->mount($__name, $__params, '3ZKFIbA', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-4">

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Imagen principal</strong>
                </div>
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.items.update-image', ['item' => $service->item]);

$__html = app('livewire')->mount($__name, $__params, 'hO8CiYI', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <strong># Duración</strong>
                </div>

                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.services.update-service', ['service' => $service]);

$__html = app('livewire')->mount($__name, $__params, 'ZnJRy7X', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/service-edit-component.blade.php ENDPATH**/ ?>