<?php

namespace Facades\App\Livewire\Actions\Dashboard\Sponsor;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Livewire\Actions\Dashboard\Sponsor\DeleteAction
 */
class DeleteAction extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Livewire\Actions\Dashboard\Sponsor\DeleteAction';
    }
}
