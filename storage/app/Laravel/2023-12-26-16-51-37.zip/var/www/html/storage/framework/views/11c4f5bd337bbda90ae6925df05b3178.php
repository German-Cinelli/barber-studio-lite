<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Empleados</span></li>
    <?php $__env->stopSection(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Listado de empleados</strong>
            <a href="<?php echo e(route('dashboard.employees.create')); ?>" class="btn btn-sm btn-primary float-end" type="button">
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                </svg>
                Nuevo
            </a>
        </div>

        <div class="card-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.search-component', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'MX04ns8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.employees.list-employees', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'a4BrQ7u', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employee-component.blade.php ENDPATH**/ ?>