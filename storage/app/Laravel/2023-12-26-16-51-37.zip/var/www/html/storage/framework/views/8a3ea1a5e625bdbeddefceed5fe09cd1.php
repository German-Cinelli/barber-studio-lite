<tr>
    <th scope="row"><?php echo e($category->id); ?></th>
    <td>
        <?php echo $category->trashed() ? '<del>' . $category->name . '</del>' : $category->name; ?>

    </td>
    <td><code>/<?php echo e($category->slug); ?></code></td>
    <td>
        <!--[if BLOCK]><![endif]--><?php if($category->trashed()): ?>
            <button wire:click="$parent.restore(<?php echo e($category->id); ?>)" class="btn btn-outline-success" type="button" title="Restaurar">
                <i class="cil-recycle"></i>
            </button>
        <?php else: ?>
            <div class="btn-group" role="group" aria-label="Default button group">
                <button class="btn btn-outline-warning" type="button" title="Editar" data-coreui-dismiss="toast" data-coreui-target="#my-toast" aria-label="Close">
                    <i class="cil-pencil"></i>
                </button>
                <button @click="$dispatch('delete-category', { id: '<?php echo e($category->id); ?>', name: '<?php echo e($category->name); ?>' })" class="btn btn-outline-danger" type="button" title="Eliminar">
                    <i class="cil-trash"></i>
                </button>
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </td>
</tr><?php /**PATH /var/www/html/resources/views/livewire/dashboard/categories/category-item.blade.php ENDPATH**/ ?>