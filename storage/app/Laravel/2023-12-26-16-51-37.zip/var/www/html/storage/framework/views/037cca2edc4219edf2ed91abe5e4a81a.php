<div>
    <form wire:submit="save">

        <div class="row">
            <div class="col-6">
                <!--[if BLOCK]><![endif]--><?php if($form->currentLogo): ?>
                    <div>
                        <img src="<?php echo e(asset($this->small('storage/logo/', $form->currentLogo))); ?>" loading="lazy">
                    </div>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="col-6">
                <!--[if BLOCK]><![endif]--><?php if($form->logo): ?>
                    <img src="<?php echo e($form->logo->temporaryUrl()); ?>" width="150px">
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- logo -->
        <div class="mb-3">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-file','data' => ['id' => ''.e(rand()).'','name' => 'form.logo','label' => '','wire:model' => 'form.logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => ''.e(rand()).'','name' => 'form.logo','label' => '','wire:model' => 'form.logo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>

        <button type="submit" class="btn btn-light float-end">
            <svg class="icon">
                <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-cloud-upload')); ?>"></use>
            </svg>
            Reemplazar
            <div wire:loading class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/settings/update-logo.blade.php ENDPATH**/ ?>