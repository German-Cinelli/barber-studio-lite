<div class="row dark col-padding clearfix" style="background-color: #121212">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6 price-wrap">
            <div class="price-header">
                <div class="price-name">
                    <a href="javascript:void(0)" class="color">
                        <img class="avatar-img" src="<?php echo e(asset($this->verySmall('storage/items/', $service->item->image))); ?>" width="32px" alt="<?php echo e($service->item->name); ?>">
                        <?php echo e($service->item->name); ?>

                    </a>
                </div>
                <div class="price-dots">
                    <span class="separator-dots"></span>
                </div>
                <div class="price-price">
                    $<?php echo e($service->item->price); ?>

                </div>
            </div>
            <p class="price-desc"><?php echo e($service->item->description); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

    <div class="col-12 center">
        <a href="#" class="button button-large button-color d-none d-lg-block "><i class="icon-calendar2"></i> Make An Appointment</a>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/frontend/services/service-component.blade.php ENDPATH**/ ?>