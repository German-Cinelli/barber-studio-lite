<div>
    <table class="table mt-3">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Enlace</th>
                <th scope="col">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $employee_socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/brand.svg#cib-' . $social->icon)); ?>"></use>
                        </svg>
                    </th>
                    <td><?php echo e($social->pivot->href); ?></td>
                    <td>
                        <button type="button" wire:click="delete(<?php echo e($social->pivot->id); ?>)" class="btn btn-ghost-danger"  title="Eliminar">
                            <i class="cil-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employee-social/list-employee-social.blade.php ENDPATH**/ ?>