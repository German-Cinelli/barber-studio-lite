<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Productos</a></li>
        <li class="breadcrumb-item active"><span>Nuevo</span></li>
    <?php $__env->stopSection(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Nuevo producto</strong>
        </div>

        <div class="card-body">

            <div class="my-3">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.products.create-product', ['categories' => $categories,'lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'zhLhQeX', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/product-create-component.blade.php ENDPATH**/ ?>