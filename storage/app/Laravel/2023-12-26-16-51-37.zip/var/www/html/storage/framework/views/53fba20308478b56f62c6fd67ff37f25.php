<div>
    <form wire:submit="save">

        <?php echo $__env->make('livewire.dashboard.employees.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button type="submit" class="btn btn-primary float-end">
            Ingresar
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employees/create-employee.blade.php ENDPATH**/ ?>