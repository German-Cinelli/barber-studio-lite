<div>

    <?php $__env->startSection('nav-content'); ?>
        <li class="breadcrumb-item active"><span>Agenda</span></li>
    <?php $__env->stopSection(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Listado de agendas</strong>
            <a href="<?php echo e(route('dashboard.appointments.create')); ?>" class="btn btn-primary position-relative rounded-0 float-end" type="button">
                <svg class="icon">
                    <use xlink:href="<?php echo e(asset('coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                </svg>
                Nueva
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    PRO
                </span>
            </a>
        </div>

        <div class="card-body">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.search-component', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, '6dwyr7J', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.appointments.list-appointments', []);

$__html = app('livewire')->mount($__name, $__params, 'KglsgZq', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>

</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/appointment-component.blade.php ENDPATH**/ ?>