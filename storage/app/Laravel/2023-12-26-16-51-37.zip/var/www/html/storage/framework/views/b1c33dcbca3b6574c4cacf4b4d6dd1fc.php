<div wire:ignore.self class="modal fade" tabindex="-1" id="modal-update">
    <div class="modal-dialog">
        <div class="modal-content">
            <form wire:submit="save">
                <div class="modal-header">
                    <h5 class="modal-title">Editar sponsor</h5>
                    <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <?php echo $__env->make('livewire.dashboard.sponsors.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="row">
                        <div class="col-6">
                            <label for="">Actual:</label>
                            <br>
                            <!--[if BLOCK]><![endif]--><?php if(isset($form->currentImage)): ?>
                                <img src="<?php echo e(asset($this->verySmall('storage/sponsors/', $form->currentImage))); ?>" width="64px" loading="lazy">
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="col-6">
                            <label for="">Nueva:</label>
                            <br>
                            <!--[if BLOCK]><![endif]--><?php if($form->image): ?>
                                <img src="<?php echo e($form->image->temporaryUrl()); ?>" width="64px">
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-warning">
                        Actualizar
                        <div wire:loading.delay class="spinner-border spinner-border-sm" role="status">
                            <span class="visually-hidden"></span>
                        </div>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/sponsors/update-sponsor.blade.php ENDPATH**/ ?>