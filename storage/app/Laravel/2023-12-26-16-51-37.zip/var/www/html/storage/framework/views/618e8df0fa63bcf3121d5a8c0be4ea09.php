<div>
    <form wire:submit="save">

        <div class="text-center mb-3">
            <!--[if BLOCK]><![endif]--><?php if($form->currentImage): ?>
                <div>
                    <img src="<?php echo e(asset($this->small('storage/employees/', $form->currentImage))); ?>" style="border-radius:50%;" loading="lazy">
                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>

        <?php echo $__env->make('livewire.dashboard.employees.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button type="submit" class="btn btn-warning float-end">
            Actualizar
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/employees/update-employee.blade.php ENDPATH**/ ?>