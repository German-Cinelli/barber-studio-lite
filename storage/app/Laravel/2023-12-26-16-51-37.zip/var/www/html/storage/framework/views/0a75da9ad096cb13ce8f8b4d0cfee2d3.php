<div>
    <div class="row">
        <div class="col-12">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <img src="<?php echo e(asset($this->verySmall('storage/items/', $image->image))); ?>" loading="lazy">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-info" role="alert">
                    Sin resultados.
                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/dashboard/images/list-images.blade.php ENDPATH**/ ?>