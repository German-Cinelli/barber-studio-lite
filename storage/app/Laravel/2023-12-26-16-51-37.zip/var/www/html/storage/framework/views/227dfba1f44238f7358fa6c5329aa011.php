<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
    <?php echo e($quantity); ?>

</span><?php /**PATH /var/www/html/resources/views/livewire/dashboard/orders/notify-icon.blade.php ENDPATH**/ ?>