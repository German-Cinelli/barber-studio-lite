<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'value', 'label', 'badge']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'value', 'label', 'badge']); ?>
<?php foreach (array_filter((['name', 'value', 'label', 'badge']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="form-check">
    <input id="radio-<?php echo e($value); ?>" value="<?php echo e($value); ?>" class="form-check-input" type="radio" id="<?php echo e($name); ?>" <?php echo e($attributes); ?>>
    <label class="form-check-label" for="radio-<?php echo e($value); ?>">
        <?php echo e($label); ?>

    </label>
    <!--[if BLOCK]><![endif]--><?php if(isset($badge)): ?>
        <span class="badge badge-sm bg-danger" style="margin-left: 1em"><?php echo e($badge); ?></span>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->


</div>
<?php /**PATH /var/www/html/resources/views/components/input-radio.blade.php ENDPATH**/ ?>