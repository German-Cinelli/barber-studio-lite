<div class="text-center">
    <div class="fslider testimonial testimonial-full bg-transparent border-0 shadow-none p-0 bottommargin-sm mx-auto center clearfix"
        data-arrows="false" style="max-width: 700px">
        <div class="flexslider">
            <div class="slider-wrap">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $instagram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide">
                        <?php echo $feed->content; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/frontend/instagram/list-instagram.blade.php ENDPATH**/ ?>