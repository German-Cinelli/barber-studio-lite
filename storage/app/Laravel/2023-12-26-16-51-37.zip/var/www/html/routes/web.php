<?php

use Illuminate\Support\Facades\Route;

use App\Livewire\Dashboard\HomeComponent;

use App\Livewire\Dashboard\EmployeeComponent;
use App\Livewire\Dashboard\EmployeeCreateComponent;
use App\Livewire\Dashboard\EmployeeEditComponent;

use App\Livewire\Dashboard\CustomerComponent;
use App\Livewire\Dashboard\CustomerShowComponent;

use App\Livewire\Dashboard\CategoryComponent;

use App\Livewire\Dashboard\ItemCreateComponent;

use App\Livewire\Dashboard\ProductComponent;

use App\Livewire\Dashboard\ProductEditComponent;

use App\Livewire\Dashboard\ServiceComponent;
use App\Livewire\Dashboard\ServiceEditComponent;

use App\Livewire\Dashboard\InstagramFeedComponent;

use App\Livewire\Dashboard\SponsorComponent;

use App\Livewire\Dashboard\BoardComponent;

use App\Livewire\Dashboard\SettingsComponent;

use App\Livewire\Dashboard\OrderComponent;
use App\Livewire\Dashboard\OrderShowComponent;
use App\Livewire\Dashboard\OrderPrintComponent;


use App\Livewire\Dashboard\AppointmentComponent;
use App\Livewire\Dashboard\AppointmentCreateComponent;





/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::view('/', 'welcome');

Route::view('dashboard', 'dashboard')
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');

require __DIR__.'/auth.php';

Route::get('/dashboard', HomeComponent::class)->name('dashboard');

Route::get('/dashboard/employees', EmployeeComponent::class)->name('dashboard.employees');
Route::get('/dashboard/employees/create', EmployeeCreateComponent::class)->name('dashboard.employees.create');
Route::get('/dashboard/employees/{id}/edit', EmployeeEditComponent::class)->name('dashboard.employees.edit');

Route::get('/dashboard/customers', CustomerComponent::class)->name('dashboard.customers');
Route::get('/dashboard/customers/{id}', CustomerShowComponent::class)->name('dashboard.customers.show');




Route::get('/dashboard/categories', CategoryComponent::class)->name('dashboard.categories');

Route::get('/dashboard/items/create', ItemCreateComponent::class)->name('dashboard.items.create');

Route::get('/dashboard/products', ProductComponent::class)->name('dashboard.products');
Route::get('/dashboard/products/{id}/edit', ProductEditComponent::class)->name('dashboard.products.edit');

Route::get('/dashboard/services', ServiceComponent::class)->name('dashboard.services');
Route::get('/dashboard/services/{id}/edit', ServiceEditComponent::class)->name('dashboard.services.edit');

Route::get('/dashboard/instagram_feeds', InstagramFeedComponent::class)->name('dashboard.instagram_feeds');

Route::get('/dashboard/sponsors', SponsorComponent::class)->name('dashboard.sponsors');

Route::get('/dashboard/board', BoardComponent::class)->name('dashboard.board');

Route::get('/dashboard/settings', SettingsComponent::class)->name('dashboard.settings');


Route::get('/dashboard/orders', OrderComponent::class)->name('dashboard.orders');

Route::get('/dashboard/orders/{order}', OrderShowComponent::class)->name('dashboard.orders.show');

Route::get('/dashboard/orders/print/{order}', OrderPrintComponent::class)->name('dashboard.orders.print');

Route::get('/dashboard/appointments', AppointmentComponent::class)->name('dashboard.appointments');
Route::get('/dashboard/appointments/create', AppointmentCreateComponent::class)->name('dashboard.appointments.create');

